package com.example.menuymapa;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nomEvento;
    Button confirmar,ubiEvento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nomEvento = findViewById(R.id.nomEventoFiltro);
        confirmar = findViewById(R.id.confirmar);
        ubiEvento = findViewById(R.id.abrirMapa);



        ubiEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombreEvento = nomEvento.getText().toString();
                Intent intent;
                intent = new Intent(MainActivity.this, UbicarMapa.class);
                intent.putExtra("NombreEvento",nombreEvento);
                startActivity(intent);
            }
        });
    }
}